# PyHeap

This module is a small wrapper class around the Python heapq module. 
While there are advantages to having the heap functions as free functions in a separate module, 
there are times where it makes sense to have a heap object
and to be able to interact with it in a more object-oriented way.

You can find this package on PyPI (link coming soon)